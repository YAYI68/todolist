import { resolvers as TodoResolver } from "./Todo.js";

export default [TodoResolver];
