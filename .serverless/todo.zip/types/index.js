import { TodoSchema } from "./todo.types.js";

export default [TodoSchema];
